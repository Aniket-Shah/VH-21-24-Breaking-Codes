import React from 'react';
import Header from '../Header/header';
import { Card, CardBody, Col, Container, Row } from 'reactstrap';

const Dams = () => {
	return (
		<>
			<Header />
			<Container>
				<Row>
					<center>
						<Col lg={6} style={{ marginTop: '10vh' }}>
							<Card>
								<CardBody>
									<h5>Dam 1</h5>
								</CardBody>
							</Card>
						</Col>
					</center>
				</Row>
			</Container>
		</>
	);
};

export default Dams;
