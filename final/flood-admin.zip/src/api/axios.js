import axios from 'axios';

axios.defaults.baseURL = `https://vcet-flood.herokuapp.com`;

const api = axios;

export default api;
