module.exports = {
	model: require('./models').model,
	handlers: require('./handlers'),
	helpers: require('./helpers'),
};
