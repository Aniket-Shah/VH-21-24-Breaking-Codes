# VCET-hack-backend
VCET hackathon backend

.env file:
```
MONGO_SERVER_URI=<your DB URL>
JWT_SECRET=<Private-key>
TWILIO_ACCOUNT_SID=<Twilio-acc-id>
TWILIO_AUTH_TOKEN=<Twilio-auth-token>
```
